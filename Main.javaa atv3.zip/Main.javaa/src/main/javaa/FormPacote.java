package main.javaa;

import javax.swing.*;
import java.awt.*;

public class FormPacote extends JFrame {

    public FormPacote() {
        setTitle("Cadastro de Pacote");
        setSize(400, 250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel painel = new JPanel(new GridLayout(4, 2, 10, 10));

        painel.add(new JLabel("Nome do Pacote:"));
        JTextField txtNome = new JTextField();
        painel.add(txtNome);

        painel.add(new JLabel("Preço:"));
        JTextField txtPreco = new JTextField();
        painel.add(txtPreco);

        painel.add(new JLabel("Tipo:"));
        JComboBox<String> cbTipo = new JComboBox<>(
            new String[]{"Praia", "Serra", "Internacional"}
        );
        painel.add(cbTipo);

        JButton btnSalvar = new JButton("Salvar");
        JButton btnVoltar = new JButton("Voltar");

        btnSalvar.addActionListener(e ->
            JOptionPane.showMessageDialog(
                this,
                "Pacote cadastrado com sucesso!"
            )
        );

        btnVoltar.addActionListener(e -> {
            new MainMenu().setVisible(true);
            dispose();
        });

        painel.add(btnSalvar);
        painel.add(btnVoltar);

        add(painel);
    }
}

