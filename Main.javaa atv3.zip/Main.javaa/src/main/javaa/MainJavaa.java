package main.javaa;

import javax.swing.SwingUtilities;

import javax.swing.SwingUtilities;

public class MainJavaa {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new MainMenu().setVisible(true);
        });
    }
}
