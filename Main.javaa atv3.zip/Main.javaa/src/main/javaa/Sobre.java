package main.javaa;

import javax.swing.*;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class Sobre extends JFrame {

    public Sobre() {
        setTitle("Sobre o Sistema");
        setSize(400, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JLabel lblTexto = new JLabel(
            "<html><center>"
            + "<h2>Sistema de Pacotes de Viagem</h2>"
            + "<p>Projeto Integrador - Etapa 3</p>"
            + "<p>Desenvolvido em Java (Swing)</p>"
            + "</center></html>",
            SwingConstants.CENTER
        );

        JButton btnVoltar = new JButton("Voltar");
        btnVoltar.addActionListener(e -> {
            new MainMenu().setVisible(true);
            dispose();
        });

        add(lblTexto, "Center");
        add(btnVoltar, "South");
    }
}
