package main.javaa;
import javax.swing.*;
import java.awt.*;

    
public class MainMenu extends JFrame {

    public MainMenu() {
        setTitle("Menu Principal");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JButton btnCadastro = new JButton("Cadastrar Pacote");
        JButton btnLista = new JButton("Listar Pacotes");
        JButton btnSobre = new JButton("Sobre");

        btnCadastro.addActionListener(e -> {
           dispose();
        });

        btnLista.addActionListener(e -> {
            new ListaPacotes().setVisible(true);
            dispose();
        });

        btnSobre.addActionListener(e -> {
            new Sobre().setVisible(true);
            dispose();
        });

        JPanel painel = new JPanel(new GridLayout(3, 1, 10, 10));
        painel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));
        painel.add(btnCadastro);
        painel.add(btnLista);
        painel.add(btnSobre);

        add(painel);
    }
}

