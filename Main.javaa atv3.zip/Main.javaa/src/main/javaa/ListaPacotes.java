package main.javaa;



import javax.swing.*;

import javax.swing.JFrame;

public class ListaPacotes extends JFrame {

    public ListaPacotes() {
        setTitle("Lista de Pacotes");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        String[] pacotes = {
            "Pacote Praia - R$ 1.500",
            "Pacote Serra - R$ 1.200",
            "Pacote Internacional - R$ 4.500"
        };

        JList<String> lista = new JList<>(pacotes);
        JScrollPane scroll = new JScrollPane(lista);

        JButton btnVoltar = new JButton("Voltar");
        btnVoltar.addActionListener(e -> {
            new MainMenu().setVisible(true);
            dispose();
        });

        add(scroll, "Center");
        add(btnVoltar, "South");
    }
}
