package principal;

public class Reserva {
    private int id;
    private Cliente cliente;
    private Pacote pacote;

    public Reserva(Cliente cliente, Pacote pacote) {
        this.cliente = cliente;
        this.pacote = pacote;
    }

    @Override
    public String toString() {
        return "Reserva de " + cliente + " | Pacote: " + pacote;
    }
}
