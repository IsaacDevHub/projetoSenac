
package principal;


public class Pacote {
    private int id;
    private String nome;
    private double preco;

    public Pacote(String nome, double preco) {
        this.nome = nome;
        this.preco = preco;
    }

    @Override
    public String toString() {
        return nome + " - R$" + preco;
    }
}

