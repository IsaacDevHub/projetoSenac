package principal;
public class Produto {
    private int id;
    private String nome;
    private String tipo;
    private double preco;

    public Produto(String nome, String tipo, double preco) {
        this.nome = nome;
        this.tipo = tipo;
        this.preco = preco;
    }

    @Override
    public String toString() {
        return nome + " - R$" + preco;
    }
}

