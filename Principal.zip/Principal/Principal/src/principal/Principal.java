package principal;


public class Principal {

   
    public static void main(String[] args) {
        Cliente c1 = new Cliente("Isaac", "isaac@gmail.com", "31999999999");
        Pacote p1 = new Pacote("Pacote Rio de Janeiro", 1500.00);

        Reserva r1 = new Reserva(c1, p1);

        System.out.println("=== Protótipo de Reserva ===");
        System.out.println(r1);
    }
}

    
